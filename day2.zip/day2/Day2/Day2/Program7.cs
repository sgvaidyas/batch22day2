﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program7
    {
        static void Main(string[] args)
        {
            int i, j, n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for (i = 1; i <= n; i++)
            {
                for (j = 1; j <= n; j++)
                {
                    Console.Write((i == 1 || i == n||j==1||j==n||i==j||j==n-i+1)?"*" : " "   );
                }
                Console.WriteLine();
            }
        }
    }
}
