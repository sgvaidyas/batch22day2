﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program9
    {
        static void Main(string[] args)
        {
            long dig=0, n,sum=0,rem;
            Console.WriteLine("Enter the value of n = ");
            n = Convert.ToInt64(Console.ReadLine());

            while(n>0)
            {
                rem = n % 10;
                sum += rem;
                n /= 10;
                dig++;
            }
            Console.WriteLine("The num of digits = " + dig);
            Console.WriteLine("The sum of all digits of num = "+sum);
        }
    }
}
