﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program4
    {
        static void Main(string[] args)
        {
            int i, n,res;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for(i=1,res=1;i<=n+1;i++,res *=2)
            {
                Console.WriteLine(res);
            }
        }
    }
}
