﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program11
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            Console.WriteLine("the sqrt of {0} is {1}",n,Math.Sqrt(n));

            double x = Math.Sqrt(n);
            Console.WriteLine("CEIL = " + Math.Ceiling(x));
            Console.WriteLine("FLOOR = " + Math.Floor(x));


            if (x - Math.Ceiling(x) == 0)
                Console.WriteLine(n + " is a Perfect square ");
            else
                Console.WriteLine(n + " is not a Perfect square ");

        }
    }
}
