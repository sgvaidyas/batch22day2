﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i,j=1;
            int n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());
            Console.WriteLine("____________");
            for(i=1;i<=n;i++)
            {
                Console.WriteLine(j);
                j += 3;
            }
        }
    }
}
