﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program3
    {
        static void Main(string[] args)
        {
            int i, n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for(i=1;i<=n;i++)
            {
                if (i == n)
                    Console.Write("\t" + i);
                else
                    Console.Write("\t"+ i + "\t" + n--);
            }
            Console.WriteLine();
        }
    }
}