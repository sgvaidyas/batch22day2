﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program2
    {
        static void Main(string[] args)
        {
            int i, n;

            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for(i=1;i<=n;i++)
            {
                Console.Write(i*(n-i+1) +"\t");                
            }
        }
    }
}
