﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program5
    {
        static void Main(string[] args)
        {
            int i, n, res=1,sum=0;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for(i=1;i<=n;i++)
            {
                res = res * i;
                sum = sum + res;
                Console.Write(res + " ");
            }
            Console.WriteLine(" = " + sum);
        }
    }
}
