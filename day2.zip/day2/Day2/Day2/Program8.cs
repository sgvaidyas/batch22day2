﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program8
    {
        static void Main(string[] args)
        {
            int i, j,k, n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());

            for(i=1;i<=n;i++)
            {
                for(j=1;j<=n-i;j++)
                    Console.Write(" ");
                for (j=1;j<=i;j++)
                    Console.Write(j);
                for (k = j - 2; k >= 1; k--)
                    Console.Write(k);
                Console.WriteLine();
            }
        }
    }
}
