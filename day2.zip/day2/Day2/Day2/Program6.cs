﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program6
    {
        static void Main(string[] args)
        {
            int i, j, n;
            Console.WriteLine("Enter the value of n = ");
            n = int.Parse(Console.ReadLine());
            int m = (n%2==1)?(n + 1) / 2 : n/2 ;
            for (i = 1; i <= n; i++)
            {
                for (j = 1; j <=m; j++)
                {
                    Console.Write((j==1 || i==j || i+j == n+1)?"*" :" ");
                }
                Console.WriteLine();
            }
        }
    }
}
